// index.js
console.log('我要学好前端，因为学好前端可以： ')