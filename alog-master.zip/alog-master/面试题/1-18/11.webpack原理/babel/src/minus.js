export const minus = (a, b) => {
    return a - b
}